<!DOCTYPE html>
<html lang="en">

<head>
   <meta charset="UTF-8">
   <meta http-equiv="X-UA-Compatible" content="IE=edge">
   <meta name="viewport" content="width=device-width, initial-scale=1.0">

   <link href="./css/style.min.css?_v=20230227105722" rel="stylesheet" type="text/css">

   <title>Document</title>

</head>

<body>
   
<div class="ss"> Привет </div>

   <div>

      Lorem ipsum dolor sit amet consectetur adipisicing elit. Reiciendis cupiditate, ducimus non, rerum qui architecto ullam blanditiis, ab sit modi error, inventore repudiandae quisquam ipsa? Molestiae nobis ut voluptatibus dicta.

   </div>

   <script src="js/app.min.js?_v=20230227105722"></script>
</body>


</html>